
package bamcocola;

public interface Node {
    
    public Node getNext();
    public void setNext(Node next);
    public int getData();
    public void setData(int data);
}
