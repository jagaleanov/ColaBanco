package bamcocola;

public class NodeClient implements Node{
    private Node next;
    
    private int data;

    @Override
    public Node getNext() {
        return this.next;
    }

    @Override
    public void setNext(Node next) {
        this.next = next;
    }

    @Override
    public int getData() {
        return this.data;
    }

    @Override
    public void setData(int data) {
        this.data = data;
    }
    
    
}
